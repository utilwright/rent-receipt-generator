# Rent Receipt product — case content (ready to POST to /store/case)

PRODUCT: Fillable Rent Receipt — €9 one-time, for landlords and tenants
SUMMARY: A single HTML file you open in any browser. Fill in landlord, tenant, amount, period, property, payment method, note, and date; print or save as PDF. No install, no account, no subscription, nothing phones home. Unlimited receipts.
BUYER: Private landlords and tenants who need clean rent receipts for records and taxes, without signing up for accounting software or fiddling with templates.
PRICE_EUR: 9
WHY_PAY: Accounting software (QuickBooks, FreshBooks) charges $20–50/month just to print a receipt. Free receipt apps exist but many require signups, paywall the basic format, or generate ugly PDFs. This is €9 once, open one file, print or save as PDF, keep forever.
DEMAND_EVIDENCE:
  - url: https://apps.apple.com/us/app/monthly-rent-receipt/id687614131
    quote: "If you are a landlord, or a tenant wanting your landlord to give you a receipt for renting, the Monthly Rent Receipt app would come in handy."
  - url: https://apps.apple.com/us/app/rent-receipt-hra-proof/id6773070507
    quote: "pay once, own it forever, your data stays on your iPhone"
COMPETITORS:
  - name: QuickBooks, url: https://apps.apple.com/us/app/intuit-quickbooks-for-business/id584606479, price: subscription $20–50/mo
  - name: Receipt Maker - Sign & Send, url: https://apps.apple.com/us/app/receipt-maker-sign-send/id1573878629, price: free
  - name: Monthly Rent Receipt, url: https://apps.apple.com/us/app/monthly-rent-receipt/id687614131, price: $0.99
  - name: Rent Receipt Pro, url: https://apps.apple.com/us/app/rent-receipt-pro/id1071189681, price: $0.99
DELIVERY:
  how: ZIP download after payment; buyer unzips and opens rent-receipt.html in any browser, fills fields, prints or saves as PDF. Delivery tested: true.
  test_note: rent-receipt.html is a standalone fillable form; opens in any browser; print-to-PDF works. No server, no dependencies, no install.
DOWNSIDES:
  - No automatic email delivery (handled: buyer prints/saves PDF themselves; documented).
  - Manual data entry per receipt (handled: takes two minutes; it's a receipt generator, not a full property-management system).
  - Single HTML file can be copied after purchase (handled: low price €9, honesty-based digital product; documented).
