Rent Receipt Template
====================
Single HTML file. Open it in any browser, fill in date/amount/tenant/property/method,
click "Preview & Print", then print or save as PDF.

No account, no install, no subscription. €9 one-time. Keep the file and reuse it
for every tenant.

How to use:
1. Open Rent_Receipt_Template.html in Chrome, Edge, Safari or Firefox.
2. Fill in the fields.
3. Click "Preview & Print".
4. Press Ctrl+P (or Cmd+P) and choose "Save as PDF" to keep a copy.
